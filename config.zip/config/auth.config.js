module.exports = {
  secret: "the-secret-key-can-be-anything",
};
